package com.mie.model;

public class Product {
	
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Product object.
	 */
	
	private int brandID;
	private String skinType;
	private int productID;
	private String productType;
	private String purpose;
	private String productName;
	private int ratings;
	private String usage;
	private String activeIngredient;
	private double price;
	private int size;
	private double pricePerMl;

	
	public int setBrandID(int bID) {
		return this.brandID = bID;
	}

	public String setSkinType(String sT) {
		return this.skinType = sT;
	}
	
	public int setProductID( int pID) {
		return this.productID = pID;
	}

	public String setProductType(String pT) {
		return this.productType = pT;
	}
	
	public String setPurpose(String p) {
		return this.purpose = p;
	}

	public String setProductName(String pN) {
		return this.productName = pN;
	}
	
	public int setRating(int r) {
		return this.ratings = r;
	}
	
	public String setUsage(String u) {
		return this.usage = u;
	}
	
	public String setActiveIngredient(String aI) {
		return this.activeIngredient = aI;
	}
	
	public double setPrice(double pr) {
		return this.price = pr;
	}
	
	public int setSize(int s) {
		return this.size = s;
	}
	
	public double setPricePerMl(double pPM) {
		return this.pricePerMl;
	}
	
	
	public int getBrandID() {
		return brandID;
	}

	public String getSkinType() {
		return skinType;
	}
	
	public int getProductID() {
		return productID;
	}

	public String getProductType() {
		return productType;
	}
	
	public String getPurpose() {
		return purpose;
	}

	public String getProductName() {
		return productName;
	}
	
	public int getRating() {
		return ratings;
	}
	
	public String getUsage() {
		return usage;
	}
	
	public String getActiveIngredient() {
		return activeIngredient;
	}
	
	public double getPrice() {
		return price;
	}
	
	public int getSize() {
		return size;
	}
	
	public double getPricePerMl() {
		return pricePerMl;
	}
	
	@Override
	public String toString() {
		return "Product [brandID=" + brandID + ", skinType=" + skinType
				+ ", productID=" + productID + ", productType=" + productType + ", purpose="
				+ purpose + ", productName=" + productName + ", ratings=" + ratings + ", usage=" 
				+ usage + ", activeIngredient=" + activeIngredient + ", price=" + price 
				+ ", size=" + size + ", pricePerMl=" + pricePerMl + "]";
	}
}
